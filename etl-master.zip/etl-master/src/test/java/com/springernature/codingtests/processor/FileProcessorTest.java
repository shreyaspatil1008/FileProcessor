package com.springernature.codingtests.processor;

import com.springernature.codingtests.exceptions.TransformationException;
import com.springernature.codingtests.formatter.Formatter;
import com.springernature.codingtests.formatter.InitCapsStringFormatter;
import com.springernature.codingtests.reader.InputFileReader;
import com.springernature.codingtests.reader.Reader;
import com.springernature.codingtests.transformer.FileTransformer;
import com.springernature.codingtests.transformer.Transformer;
import com.springernature.codingtests.writer.OutputFileWriter;
import com.springernature.codingtests.writer.Writer;
import junit.framework.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by trai01 on 25-08-2019.
 */
public class FileProcessorTest {

    @Test
    public void testProcess() throws IOException, TransformationException{
        Reader reader = new InputFileReader("src/main/resources/input-file.txt");
        Writer writer =  new OutputFileWriter("src/main/resources/output-file.txt");
        Formatter formatter =  new InitCapsStringFormatter();
        Transformer transformer = new FileTransformer(formatter);
        List<Transformer> transformers = new ArrayList<>();
        transformers.add(transformer);
        Processor processor = new FileProcessor(reader,writer,transformers);
        processor.process();
        reader = new InputFileReader("src/main/resources/output-file.txt");
        Assert.assertEquals("I  Am A    Great Coder Who Loves To Solve  Real World Problems",reader.read());
    }
}
