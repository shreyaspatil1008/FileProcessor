package com.springernature.codingtests.processor;

import com.springernature.codingtests.exceptions.TransformationException;

import java.io.IOException;

/**
 * Created by trai01 on 25-08-2019.
 */
public interface Processor {
    void process() throws IOException, TransformationException;
}
