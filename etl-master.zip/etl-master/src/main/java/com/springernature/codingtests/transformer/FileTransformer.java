package com.springernature.codingtests.transformer;

import com.springernature.codingtests.exceptions.TransformationException;
import com.springernature.codingtests.formatter.Formatter;

public class FileTransformer implements Transformer {
    private Formatter formatter;
    public FileTransformer(Formatter formatter) {
        this.formatter = formatter;
    }

    @Override
    public String transform(String content) throws TransformationException {
        try{
            return (String)formatter.format(content);
        }catch(Exception e){
            System.out.println(e.getMessage());
            throw new TransformationException("Transformation Failed");
        }
    }
}
