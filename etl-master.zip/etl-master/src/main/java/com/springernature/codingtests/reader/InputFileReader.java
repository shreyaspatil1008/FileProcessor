package com.springernature.codingtests.reader;

import java.io.BufferedReader;
import java.io.File;

public class InputFileReader implements Reader {

    private String fileName;
    public InputFileReader(String fileName){
        this.fileName = fileName;
    }

    @Override
    public String read() {
        try {
            File file = new File(fileName);
            BufferedReader br = new BufferedReader(new java.io.FileReader(file));
            StringBuilder sb = new StringBuilder();
            String str = null;

            while((str=br.readLine())!=null){
                sb.append(str);
            }
            return sb.toString();
        }
        catch(Exception e){
            throw new RuntimeException(e);
        }
    }
}
