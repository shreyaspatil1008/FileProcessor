package com.springernature.codingtests.exceptions;

/**
 * Created by trai01 on 25-08-2019.
 */
public class TransformationException extends Exception {
    private String message;
    public TransformationException(String message){
        this.message = message;
    }

    @Override
    public String getMessage(){
        return message;
    }
}
