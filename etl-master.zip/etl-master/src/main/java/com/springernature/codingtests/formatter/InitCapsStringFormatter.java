package com.springernature.codingtests.formatter;

public class InitCapsStringFormatter implements Formatter{

    @Override
    public String format(Object input){
        if(input != null){
            StringBuilder sb = new StringBuilder();
            String words[] = input.toString().split(" ");
            for(String word : words){
                Character ch = word.charAt(0);
                String newWord = ch.toString().toUpperCase() + word.substring(1);
                sb.append(newWord).append(" ");
            }
            return sb.toString();
        }
        return null;
    }
}
