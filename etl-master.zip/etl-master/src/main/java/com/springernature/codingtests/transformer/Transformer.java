package com.springernature.codingtests.transformer;

import com.springernature.codingtests.exceptions.TransformationException;

public interface Transformer {
    Object transform(String content)throws TransformationException;
}
