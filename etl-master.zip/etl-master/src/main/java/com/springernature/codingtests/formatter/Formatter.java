package com.springernature.codingtests.formatter;


public interface Formatter {
    Object format(Object input);
}
