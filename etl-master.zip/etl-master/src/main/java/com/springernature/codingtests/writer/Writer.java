package com.springernature.codingtests.writer;

import java.io.IOException;

public interface Writer {
    void write(String content) throws IOException;
}
