package com.springernature.codingtests.reader;

public interface Reader {
    String read();
}
