package com.springernature.codingtests.writer;

import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by trai01 on 04-08-2019.
 */
public class OutputFileWriter implements Writer {

    private String fileName;
    public OutputFileWriter(String fileName){
        this.fileName = fileName;
    }

    @Override
    public void write(String content) throws IOException {
        FileWriter fw = new FileWriter(fileName);//"src/main/resources/output-file.txt"
        fw.write(content.toString());
        fw.close();
    }
}
