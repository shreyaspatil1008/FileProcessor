package com.springernature.codingtests.processor;

import com.springernature.codingtests.exceptions.TransformationException;
import com.springernature.codingtests.reader.Reader;
import com.springernature.codingtests.transformer.Transformer;
import com.springernature.codingtests.writer.Writer;

import java.io.IOException;
import java.util.List;

public class FileProcessor implements Processor {

    private Reader reader;
    private Writer writer;
    private List<Transformer> transformers;

    public FileProcessor(Reader reader,Writer writer,List<Transformer> transformers){
        this.reader = reader;
        this.writer = writer;
        this.transformers = transformers;
    }

    @Override
    public void process() throws IOException, TransformationException {
        String input = reader.read();
        for(Transformer transformer: transformers){
            input = (String)transformer.transform(input);
        }
        writer.write(input);
    }
}
